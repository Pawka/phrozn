<?php
/**
 * Copyright 2011 Victor Farazdagi
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 *
 *          http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 *
 * @category    Phrozn
 * @package     Phrozn\Site\View
 * @author      Victor Farazdagi
 * @copyright   2011 Victor Farazdagi
 * @license     http://www.apache.org/licenses/LICENSE-2.0
 */

namespace Phrozn\Site\View;
use Symfony\Component\Yaml\Yaml,
    Phrozn\Has;

/**
 * View producing factory
 *
 * @category    Phrozn
 * @package     Phrozn\Site\View
 * @author      Victor Farazdagi
 */
class Factory 
    implements Has\InputFile
{
    /**
     * Site\View\Html is default page type
     */
    const DEFAULT_VIEW_TYPE = 'html';

    /**
     * By default assume default.twig as layout input file
     */
    const DEFAULT_LAYOUT_SCRIPT = 'default.twig';

    /**
     * Path to input file
     * @var string
     */
    private $inputFile;

    /**
     * Initialize factory by providing input file path
     *
     * @param string $path Path to page source file
     *
     * @return void
     */
    public function __construct($path = null)
    {
        $this->setInputFile($path);
    }

    /**
     * Depending on internal configuration and concrete type, create view
     *
     * return \Phrozn\Site\View\Factory
     */
    public function create()
    {
        $ext = pathinfo($this->getInputFile(), PATHINFO_EXTENSION);

        $type = $ext ? : self::DEFAULT_VIEW_TYPE;

        return $this->constructFile($type);
    }

    /**
     * Set input file path
     *
     * @param string $path Path to file
     *
     * @return \Phrozn\Site\View\Factory
     */
    public function setInputFile($path)
    {
        if (null !== $path) {
            if (!is_readable($path)) {
                throw new \Exception("View source file cannot be read: {$path}");
            }
            $this->inputFile = $path;
        }

        return $this;
    }

    /**
     * Get input file path
     *
     * @return string
     */
    public function getInputFile()
    {
        return $this->inputFile;
    }

    /**
     * Create and return view of a given type
     *
     * @param string $type File type to load
     *
     * @return \Phrozn\Site\View
     */
    private function constructFile($type)
    {
        $class = 'Phrozn\\Site\\View\\' . ucfirst($type);
        if (!class_exists($class)) {
            throw new \Exception("View of type '{$type}' not found..");
        }
        $object = new $class;
        $object->setInputFile($this->getInputFile());
        return $object;
    }
}
